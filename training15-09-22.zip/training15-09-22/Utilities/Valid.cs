﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilities
{
    public class Valid
    {
         public static int validInteger()
    {
            Console.WriteLine("Enter the number");
            
        int NumberOfUser;
        // Console.WriteLine("enter the number of user");
        Boolean bul = int.TryParse(Console.ReadLine(), out NumberOfUser);
        if (bul == true)
        {
            return NumberOfUser;
        }
        else
        {
            Console.WriteLine("Enter the valid number again");
            return NumberOfUser = validInteger();

        }
        return NumberOfUser;
    }

}
}
