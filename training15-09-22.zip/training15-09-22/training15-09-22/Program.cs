﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Utilities;

namespace training15_09_22
{
    internal class Program
    {
        static void Main(string[] args)
        {


            // User.usernames();
            //SquareAray.SquareArray();

            //******assignment******
            //Prog1.Assg1();
            // Prog2.Assg2();
            //Prog3.Assg3();
            // Prog4.Assg4();
            //Prog5.Assg5();
            Prog6.Assg6();
            //Prog7.Assg7();



            //Class library methods

            // Valid.validInteger();


        }
    }
}
