﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace training15_09_22
{
    internal class Prog5
    {
        public static void Assg5() 
        {
           // Console.WriteLine("Enter the number of products");
            //int cnt = validate_inputs.validInteger(Console.ReadLine());
            List<product> pList = new List<product>();

            for (int i = 0; i < 2; i++)
            {
                Console.WriteLine("Enter product details brand , product name, price");
                pList.Add(new product { brand = Console.ReadLine(), name = Console.ReadLine(), price = validate_inputs.validInteger(Console.ReadLine()) });

            }
            Console.WriteLine("==================================");

          
            var QuerySyntax = (from pli in pList
                              orderby pli.price descending
                               select pli.price).First();
            Console.WriteLine("==================================");

            Console.WriteLine(" highest price for those two brands");
            
                Console.WriteLine(QuerySyntax);
            

            Console.ReadLine();
        }
    }
}
