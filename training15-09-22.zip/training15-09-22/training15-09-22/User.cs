﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace training15_09_22
{
    public class User
    {
        
        public static void usernames() 
        {
        askAgain:
            Console.WriteLine("enter the number of user");
            int NumberOfUser=validate_inputs.validInteger(Console.ReadLine());
            Console.WriteLine("===============================");

            
                String[] UserArray = new string[NumberOfUser];
                for (int i = 0; i < NumberOfUser; i++)
                {
                    Console.WriteLine("Enter the name of user");

                    UserArray[i] = Console.ReadLine();
                }
                var QuerySyntax = (from li in UserArray
                                   where li.StartsWith("s")
                                   select li).ToList();
                Console.WriteLine("===============================");
                Console.WriteLine("Names starts with 's'  ");
                foreach (var item in QuerySyntax)
                {
                    Console.WriteLine(item);
                }
          
                

            
            Console.ReadLine();
        }

       
       /* public static void usernames()
        {
        askAgain:
            Console.WriteLine("enter the number of user");
            Boolean bul = int.TryParse(Console.ReadLine(), out int NumberOfUser);

            Console.WriteLine("===============================");

            if (bul == true)
            {
                String[] UserArray = new string[NumberOfUser];
                for (int i = 0; i < NumberOfUser; i++)
                {
                    Console.WriteLine("Enter the name of user");

                    UserArray[i] = Console.ReadLine();
                }
                var QuerySyntax = (from li in UserArray
                                   where li.StartsWith("s")
                                   select li).ToList();
                Console.WriteLine("===============================");
                Console.WriteLine("Names starts with 's'  ");
                foreach (var item in QuerySyntax)
                {
                    Console.WriteLine(item);
                }
            }
            else
            {
                Console.WriteLine("Enter valid input");
                goto askAgain;
            }
            Console.ReadLine();
        }*/


    }
}

