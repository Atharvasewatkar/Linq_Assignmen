﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace training15_09_22
{
    public class product
    {
        public string brand;
        public string name;
        public int price;


      /*  public product(String brand, String name, int price) 
        {
            this.brand = brand;
            this.name = name;
            this.price = price;
        }*/

    }
}
