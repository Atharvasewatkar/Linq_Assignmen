﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;

namespace training15_09_22
{
    public class SquareAray
    {
        public static void SquareArray() 
        {

            Console.WriteLine("Enter the number of elements");
            String msg = Console.ReadLine();
           int no_element= validate_inputs.validInteger(msg);
             
            Console.WriteLine("===========================");

            int[] sq_Array= new int[no_element];
            int[] sq_outArray=new int[no_element];
            int index = 0;
            for (int i = 0; i < sq_Array.Length; i++) 
            {
                Console.WriteLine("Enter elements");

                sq_Array[i] = validate_inputs.validInteger(Console.ReadLine());
            }
            //int squareValue = 0;
            for (int i = 0; i < sq_outArray.Length; i++)
            {
                 //int squareValue = sq_Array[i] * sq_Array[i];
                sq_outArray[index++]= sq_Array[i] * sq_Array[i];
            }
            //Linq
            var QuerySyntax=(from ar in sq_outArray
                             select ar).ToList();

            Console.WriteLine("===========================");
            Console.WriteLine("Square Array of entered number");

            foreach (var item in QuerySyntax)
            {
                Console.WriteLine(item);
            }

            Console.ReadLine();

        }
    }
}
