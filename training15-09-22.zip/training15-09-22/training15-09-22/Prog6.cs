﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace training15_09_22
{
    internal class Prog6
    {
        public static void Assg6() 
        {
            Console.WriteLine("Enter the number of products");
            int cnt = validate_inputs.validInteger(Console.ReadLine());
            List<product> pList = new List<product>();

            for (int i = 0; i < cnt; i++)
            {
                Console.WriteLine("Enter product details brand , product name, price");
                pList.Add(new product { brand = Console.ReadLine(), name = Console.ReadLine(), price = validate_inputs.validInteger(Console.ReadLine()) });

            }

            Console.WriteLine("Enter brand name");
            String ss = Console.ReadLine();
            var QuerySyntax = (from pli in pList
                               where pli.brand.Equals(ss)
                               select pli.name).ToList();

            Console.WriteLine("==================================");

            Console.WriteLine("product specified brand name models");
            foreach (var item in QuerySyntax)
            {
                Console.WriteLine(item);
            }
            Console.ReadLine();
        }
    }
}
