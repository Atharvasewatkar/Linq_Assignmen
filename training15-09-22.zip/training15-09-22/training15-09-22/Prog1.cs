﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;

namespace training15_09_22
{
    public  class Prog1
    {
        public static void Assg1() 
        {
            Console.WriteLine("Enter the number of products");
            int cnt = validate_inputs.validInteger(Console.ReadLine());
                     List<product> pList = new List<product>();

            for (int i = 0; i < cnt; i++)
            {
                Console.WriteLine("Enter product details brand , product name, price");
                pList.Add(new product { brand = Console.ReadLine(), name = Console.ReadLine(), price = validate_inputs.validInteger(Console.ReadLine()) });

            }
            Console.WriteLine("==================================");

            Console.WriteLine("Enter character ");
            String ss = Console.ReadLine();
            var QuerySyntax = (from pli in pList
                               where pli.name.Contains(ss)
                               select pli.name).ToList();
            Console.WriteLine("==================================");

            Console.WriteLine("product name which contains 'k'");
            foreach (var item in QuerySyntax)
            {
                Console.WriteLine(item);
            }

            Console.ReadLine();
        }
    }
}
