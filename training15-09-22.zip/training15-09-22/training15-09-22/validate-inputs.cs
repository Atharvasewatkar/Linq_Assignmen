﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace training15_09_22
{
    public class validate_inputs
    {
        public static int validInteger(String msg)
        {
            int NumberOfUser;
           // Console.WriteLine("enter the number of user");
            Boolean bul = int.TryParse(msg, out  NumberOfUser);
            if (bul == true)
            {
                return NumberOfUser;
            }
            else 
            {
            Console.WriteLine("Enter the valid number again");
              return  NumberOfUser= validInteger( Console.ReadLine());
                
            }
            return NumberOfUser;
        }
    }
}
